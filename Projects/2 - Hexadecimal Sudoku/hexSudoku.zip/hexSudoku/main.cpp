#include <iostream>
#include <stack.h>

using namespace std;

const uint32_t
    IS_FILLED_IN = 0x80000000,
    NUM_MASK = 0x0000000f,
    VALID_MASK = 0x000ffff0,
    IS_0_VALID = 0x00000010;

uint32_t
    board[16][16];

void printBoard() {

}

bool findBest(Stack<uint32_t> &s) {

}

void solve() {

}

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
