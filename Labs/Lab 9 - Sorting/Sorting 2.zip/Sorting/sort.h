// shared include files

#include <iostream>

using namespace std;

// constants, defines and macros

// data structures and classes

// global variables

// function prototypes

int Read(int [],int);
void Print(int [],int);
void sort(int [],int);
