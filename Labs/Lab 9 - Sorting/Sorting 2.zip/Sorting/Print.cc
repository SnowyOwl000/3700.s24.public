#include "sort.h"

using namespace std;

void Print(int data[],int nItems) {
   int i;
   
   for (i=0;i<nItems;i++)
      cout << data[i] << endl;
}
