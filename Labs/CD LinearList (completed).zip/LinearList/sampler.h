//
// Created by bob on 3/1/24.
//

#ifndef SAMPLER_H
#define SAMPLER_H

#include <cstdint>
#include <random>
#include <stdexcept>

class Sampler {
public:
    Sampler(uint32_t n);
    ~Sampler();

    uint32_t getSample();

private:
    uint32_t
        *elements,
        nElements;
    std::random_device
        *rd;
    std::mt19937
        *mt;
};

#endif //SAMPLER_H
