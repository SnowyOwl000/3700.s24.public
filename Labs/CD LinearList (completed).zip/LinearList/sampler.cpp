//
// Created by bob on 3/1/24.
//

#include "sampler.h"

Sampler::Sampler(uint32_t n) {

    nElements = n;

    elements = new uint32_t[nElements];
    for (uint32_t i=0;i<nElements;i++)
        elements[i] = i;

    rd = new std::random_device;

    mt = new std::mt19937((*rd)());
}

Sampler::~Sampler() {

    delete mt;

    delete rd;

    delete[] elements;
}

uint32_t Sampler::getSample() {
    uint32_t
        e,i;
    std::uniform_int_distribution<>
        dis(0,(int32_t)nElements-1);

    if (nElements == 0)
        throw std::underflow_error("getSample: Sampler is empty");

    // i = random integer in range 0 .. (nElements - 1)
    i = dis(*mt);

    // e = elements[i];
    e = elements[i];

    // n--
    nElements--;

    // elements[i] = elements[n]
    elements[i] = elements[nElements];

    // return e
    return e;
}