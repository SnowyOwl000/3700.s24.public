#include <iostream>
#include "sampler.h"
#include "cdLinearList.h"

using namespace std;

#define OPF(b) ((b) ? "pass" : "fail")

const uint32_t
    TEST1_SIZE = 10000,
    TEST2_SIZE = 100000;

uint32_t
    test1Items[TEST1_SIZE],
    test2Items[TEST2_SIZE];
bool
    okay;

void test1Compare(uint32_t &d) {
    static uint32_t
        pos = 0;

    if (d != test1Items[pos])
        okay = false;

    pos = ++pos % TEST1_SIZE;
}

void test2Compare(uint32_t &d) {
    static uint32_t
            pos = 0;

    if (d != test2Items[pos])
        okay = false;

    pos = ++pos % TEST2_SIZE;
}

void test1() {
    LinearList<uint32_t>
        myList;
    Sampler
        s(TEST1_SIZE);

    // test isEmpty with empty list
    okay = myList.isEmpty();
    cout << "isEmpty (part 1): " << OPF(okay) << endl;

    // test size with empty list
    okay = (myList.size() == 0);
    cout << "   size (part 1): " << OPF(okay) << endl;

    for (uint32_t i=0;i<TEST1_SIZE;i++) {
        uint32_t e = s.getSample();

        test1Items[i] = e;

        myList.insert(i,e);
    }

    // retest isEmpty and size
    okay = !myList.isEmpty();
    cout << "isEmpty (part 2): " << OPF(okay) << endl;

    okay = (myList.size() == TEST1_SIZE);
    cout << "   size (part 2): " << OPF(okay) << endl;

    okay = true;
    for (int32_t i=0;i<TEST1_SIZE;i++)
        if (test1Items[i] != myList[i])
            okay = false;

    cout << "              []: " << OPF(okay) << endl;

    okay = true;
    myList.traverse(test1Compare);

    cout << "  traverse / map: " << OPF(okay) << endl;

    okay = true;
    for (int32_t i=1;i<=TEST1_SIZE/2;i++)
        myList.remove(i);

    for (int32_t i=0;i<TEST1_SIZE/2;i++)
        if (myList[i] != test1Items[2*i])
            okay = false;

    cout << "          remove: " << OPF(okay) << endl;

    okay = true;
    for (uint32_t i=0;i<TEST1_SIZE/2;i++)
        try {
            if (myList.search(test1Items[2 * i]) != i)
                okay = false;
        } catch (domain_error &e) {
            okay = false;
        }

    for (uint32_t i=0;i<TEST1_SIZE/2;i++)
        try {
            myList.search(test1Items[2 * i + 1]);

            okay = false;
        } catch (domain_error &e) {
            // nothing to do, this is supposed to happen
        }

    cout << "          search: " << OPF(okay) << endl;
}

void test2() {
    LinearList<uint32_t>
        myList;
    Sampler
        s(TEST2_SIZE);

    for (uint32_t i=0;i<TEST2_SIZE;i++) {
        uint32_t e = s.getSample();

        test2Items[i] = e;

        myList.insert(i,e);
    }

    okay = true;
    for (int32_t i=0;i<TEST2_SIZE;i++)
        if (test2Items[i] != myList[i])
            okay = false;

    cout << "              []: " << OPF(okay) << endl;

    okay = true;
    myList.traverse(test2Compare);

    cout << "  traverse / map: " << OPF(okay) << endl;

    okay = true;
    myList.first();
    uint32_t
        i=0;
    do {
        if (myList.current() != test2Items[i])
            okay = false;
        i++;
        myList.curNext();
    } while (!myList.isFirst());
    okay = okay && (i == TEST2_SIZE);

    cout << "         current: " << OPF(okay) << endl;

}

void test3() {
    LinearList<uint32_t>
        myList;
    Sampler
        s(TEST1_SIZE);

    for (uint32_t i = 0; i < TEST1_SIZE; i++) {
        uint32_t e = s.getSample();

        test1Items[i] = e;

        myList.insert(i, e);
    }

    okay = true;
    for (int32_t i = -1; i > -TEST1_SIZE; i--)
        if (test1Items[TEST1_SIZE+i] != myList[i])
            okay = false;

    cout << "     backward []: " << OPF(okay) << endl;
}

int main() {

    cout << "--- test 1 ---" << endl;
    test1();

    cout << "\n--- test 2 ---" << endl;
    test2();

    cout << "\n--- test 3 ---" << endl;
    test3();

    return 0;
}