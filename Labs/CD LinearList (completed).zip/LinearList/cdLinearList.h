//
// Created by Dr. Bob Kramer on 3/21/24.
//

#ifndef CDLINEARLIST_H
#define CDLINEARLIST_H

#include <cstdint>

template <typename ListType>
struct ListNode {
    ListType
        key;                // the value stored in the node
    ListNode<ListType>
        *next,*prev;        // pointers to next and previous nodes
};

template <typename ListType>
class LinearList {
public:
    LinearList() {

        // set head to null
        head = nullptr;

        // set count to 0
        count = 0;
    }

    ~LinearList() {

        // call the clear function
        clear();
    }

    uint32_t size() { return count; }

    bool isEmpty() { return count == 0; }

    void clear() {
        ListNode<ListType>
            *tmp;

        // for i = 0 to (count-1) do
        for (uint32_t i=0;i<count;i++) {

            // remember second node in list
            tmp = head->next;

            // delete head node
            delete head;

            // set head to second node
            head = tmp;

        // end for
        }

        // set head to null
        head = nullptr;

        // set count to 0
        count = 0;
    }

    uint32_t search(const ListType &k) {
        // declare tmp pointer, initialize to head of list
        ListNode<ListType>
            *tmp = head;

        // for i = 0 to (count-1) do
        for (uint32_t i=0;i<count;i++) {

            // if k == tmp->key
            if (k == tmp->key)

                // return i
                return i;

            // move tmp to next node
            tmp = tmp->next;

        // end for
        }

        // if we get here, key not in list. Throw exception.
        throw std::domain_error("search: Key not found");
    }

    ListType &operator[](int32_t pos) {
        // declare tmp pointer, initialize to head of list
        ListNode<ListType>
            *tmp = head;

        // if pos is invalid (< -count or >= count), throw exception
        if (pos < -count || pos >= count)
            throw std::domain_error("at: Invalid index");

        if (pos < 0) {

            // for i = 0 to (pos - 1) do
            for (int32_t i = 0; i > pos; i--)

                // move tmp to previous node
                tmp = tmp->prev;

            // end for
        } else {

            // for i = 0 to (pos - 1) do
            for (int32_t i = 0; i < pos; i++)

                // move tmp to next node
                tmp = tmp->next;

            // end for
        }

        // return tmp->key
        return tmp->key;
    }

    void traverse(void (*fp)(ListType &)) {
        // declare tmp pointer, initialize to head of list
        ListNode<ListType>
            *tmp = head;

        // for i = 0 to (count - 1) do
        for (uint32_t i=0;i<count;i++) {

            // call the function, pass tmp->key
            (*fp)(tmp->key);

            // move tmp to next node
            tmp = tmp->next;

        // end for
        }
    }

    void insert(uint32_t pos,const ListType &k) {
        ListNode<ListType>
            *tmp,
            *pred,*succ;

        // step 0: make sure pos is valid (>= 0 and <= count, note the <= part)
        if (pos > count)
            throw std::domain_error("insert: Invalid index");

        // step 1: create new node, place k in the node
        tmp = new ListNode<ListType>;
        tmp->key = k;

        // zwischenzug (in-between move): if count is zero, then this is the
        // only node. set head to point here, count to 1, and skip the rest.
        // this only applies to circular, doubly-linked lists.
        if (count == 0) {
            head = tmp->next = tmp->prev = tmp;
            count = 1;
            return;
        }

        // step 2: find the predecessor (and successor)
        pred = head->prev;
        for (uint32_t i=0;i<pos;i++)
            pred = pred->next;

        succ = pred->next;

        // step 3: set up new node pointers
        tmp->next = succ;   // regular list: tmp->next = pred->next;
        tmp->prev = pred;

        // step 4: predecessor points to new node (so does successor)
        pred->next = succ->prev = tmp;

        // step 5: update count
        count++;

        // extra step: update head of list if necessary
        if (pos == 0)
            head = tmp;
    }

    void remove(uint32_t pos) {
        ListNode<ListType>
            *ntbd,
            *pred,*succ;

        // step 0: make sure pos is valid (>= 0 and < count this time)
        if (pos >= count)
            throw std::domain_error("remove: Invalid index");

        // if count is 1, set head to null, count to zero and skip the rest of this
        if (count == 1) {
            delete head;

            head = nullptr;
            count = 0;

            return;
        }

        // step 1: find the predecessor (and successor)
        pred = head->prev;
        for (uint32_t i=0;i<pos;i++)
            pred = pred->next;

        succ = pred->next->next;

        // step 2: remember the node to be deleted
        ntbd = pred->next;

        // can also set successor here: succ = ntbd->next;

        // step 3: point around NTBD
        pred->next = succ;
        succ->prev = pred;

        // step 4: delete the node
        delete ntbd;

        // step 5: adjust count
        count--;

        // extra step: update head of list if necessary
        if (pos == 0)
            head = succ;
    }

    ListType &current() {

        // if cur is set, return cur->key
        if (cur != nullptr)
            return cur->key;

        // throw exception
        throw std::domain_error("current: Current node not set");
    }

    void curNext() {

        // if cur is set, move cur to next node
        if (cur != nullptr)
            cur = cur->next;

        // else throw exception
        else
            throw std::domain_error("curNext: Current node not set");
    }

    void curPrev() {

        // if cur is set, move cur to previous node
        if (cur != nullptr)
            cur = cur->prev;

        // else throw exception
        else
            throw std::domain_error("curNext: Current node not set");
    }

    void first() {

        // if count > 0, set cur to head
        if (count > 0)
            cur = head;
    }

    void last() {

        // if count > 0, set cur to head->prev
        if (count > 0)
            cur = head->prev;
    }

    bool isFirst() {

        // return true iff count > 0 and cur == head
        return count > 0 && cur == head;
    }

    bool isLast() {

        // return true iff count > 0 and cur == head->prev
        return count > 0 && cur == head->prev;
    }

private:
    ListNode<ListType>
        *head,
        *cur;
    int32_t
        count;
};

#endif //CDLINEARLIST_H
