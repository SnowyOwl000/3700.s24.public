#include <numeric>
#include "fraction.h"

Fraction::Fraction(int32_t n,int32_t d) {

  if (d < 0) {
    n = -n;
    d = -d;
  }
  
  int32_t
    g = std::gcd(n,d);
    
  num = n / g;
  den = d / g;
}
  
Fraction Fraction::operator+(Fraction rhs) {
  int32_t
    n,d;
    
  n = num * rhs.den + den * rhs.num;
  d = den * rhs.den;
  
  return Fraction(n,d);
}

Fraction Fraction::operator-(Fraction rhs) {
  int32_t
    n,d;
    
  n = num * rhs.den - den * rhs.num;
  d = den * rhs.den;
  
  return Fraction(n,d);
}

Fraction Fraction::operator*(Fraction rhs) {
  int32_t
    n,d;
    
  n = num * rhs.num;
  d = den * rhs.den;
  
  return Fraction(n,d);
}

Fraction Fraction::operator/(Fraction rhs) {
  int32_t
    n,d;
    
  n = num * rhs.den;
  d = den * rhs.num;
  
  return Fraction(n,d);
}
  
Fraction Fraction::operator=(Fraction rhs) {

  num = rhs.num;
  den = rhs.den;
  
  return *this;
}
  
bool Fraction::operator==(Fraction rhs) { return num == rhs.num && den == rhs.den; }

bool Fraction::operator!=(Fraction rhs) { return num != rhs.num || den != rhs.den; }

bool Fraction::operator<(Fraction rhs) { return num * rhs.den < den * rhs.num; }
bool Fraction::operator>(Fraction rhs) { return num * rhs.den > den * rhs.num; }
bool Fraction::operator<=(Fraction rhs) { return num * rhs.den <= den * rhs.num; }
bool Fraction::operator>=(Fraction rhs) { return num * rhs.den >= den * rhs.num; }
  
std::istream &operator>>(std::istream &is,Fraction &f) {
  int32_t
    n,d;
  char
    slash;
    
  is >> n >> slash >> d;
  
  f = Fraction(n,d);
  
  return is;
}

std::ostream &operator<<(std::ostream &os,Fraction f) {

  os << f.getNum() << " / " << f.getDen();
  
  return os;
}

